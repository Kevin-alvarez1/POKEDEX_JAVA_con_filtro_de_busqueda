/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pokemon;

import javax.swing.JOptionPane;

public class ListaPokemon {
    private NodoPokemon root;   
    
    public ListaPokemon(){
        root = null;
    }
    
    public void insertar_pokemon(int correlativo, String nombre, String tipo, String region, int Ps, int Atk, int Def, int Vel, int AtkEsp, int DefEsp, String rareza, String direccion_imagen){
        NodoPokemon pokemon = new NodoPokemon( correlativo,  nombre,  tipo,  region,  Ps,  Atk,  Def,  Vel,  AtkEsp,  DefEsp,  rareza,  direccion_imagen);  
        if(this.getRoot()==null){
          this.setRoot(pokemon);
        }else{
          NodoPokemon aux = this.getRoot();
        while(aux.getSig()!=null){
           aux = aux.getSig();
        }
        aux.setSig(pokemon);
        pokemon.setAnt(aux);
        }
     }
    
    public NodoPokemon regresarPK(int numero){
        NodoPokemon aux = this.getRoot();
        if (aux == null) {
        }else{
            while(aux != null){
                if (numero != aux.getCorrelativo()) {
                    aux = aux.getSig();
                }else{
                    return aux;
                }
            }
        }
        return null;
    }
    
    public String mostrar(){
        NodoPokemon aux = this.getRoot();
        String cadena = "";
        while (aux != null) {
            cadena += "N° Pokedex: "+aux.getCorrelativo()+" Nombre: "+aux.getNombre_pk()+"\n";
            aux = aux.getSig();
             
        }
        return cadena;
    }
      public boolean busqueda(int num){
        NodoPokemon aux = this.getRoot();
        if (aux != null) {
            regresarPK(num);
        }else{
            return false;
        }
      return true;
    }
        public NodoPokemon regresarpk(int numero){
            NodoPokemon mal = this.getRoot();
        if(mal == null){
        JOptionPane.showMessageDialog(null, "no hay pokemon registrado");
        }else{
             while(mal != null){
                if (numero != mal.getCorrelativo()) {
                    mal = mal.getSig();
                }else{
                    return mal;
                }
            }
        }
        return null;
    }
    
    public NodoPokemon getRoot() {
        return root;
    }

    public void setRoot(NodoPokemon root) {
        this.root = root;
    }

}

