/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pokemon;

public class Matriz {
    int nfilas = 10;
    int ncol=7;
    public ListaPokemon matriz[][];

//Regiones: kanto,johto,Hoenn,Sinnoh,Teselia,Kalos,Alola
//Rarezas: comun, poco comun,legendarios, semi pseudo legendario, singular, fosiles, sub legendario, mega evolucion, ultra ente, pseudo legendario 

    public Matriz() {
        this.matriz = new ListaPokemon[this.nfilas][this.ncol];
        for(int i = 0;i<10;i++){
            for(int j=0;j<7;j++){
                this.matriz[i][j] = new ListaPokemon();
            }
        }
        System.out.println("Creadas");
    }
    public NodoPokemon buscarpokemon(int poke){
        for (int i = 0 ; i<7 ; i++){
            for(int j = 0 ; j<10 ; j++){
                NodoPokemon aux = this.matriz[j][i].regresarPK(poke);
                if(aux == null){
                continue;    
                }else{
                    return aux;
                }
            }
        }
        return null;
    }
     public boolean buscarpokemons(int poke){
        for (int i = 0 ; i<7 ; i++){
            for(int j = 0 ; j<10 ; j++){
                NodoPokemon aux = this.matriz[j][i].regresarPK(poke);
                if(aux == null){
                continue;    
                }else{
                    return true;
                }
            }
        }
        return false;
    }
}