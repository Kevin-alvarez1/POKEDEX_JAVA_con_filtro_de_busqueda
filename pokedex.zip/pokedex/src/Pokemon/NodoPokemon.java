/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pokemon;

/**
 *
 * @author Player
 */
public class NodoPokemon {
   private int correlativo;
   private String nombre_pk;
   private String tipo_pk;
   private String region;
   private int Ps;
   private int Atk;
   private int Def;
   private int Vel;
   private int AtkEsp;
   private int DefEsp;
   private String rareza;
   private String direccion_imagen;
   private NodoPokemon sig;
   private NodoPokemon ant;



    public NodoPokemon(int correlativo, String nombre_pk, String tipo_pk, String region, int Ps, int Atk, int Def, int Vel, int AtkEsp, int DefEsp, String rareza, String direccion_imagen) {
        this.correlativo = correlativo;
        this.nombre_pk = nombre_pk;
        this.tipo_pk = tipo_pk;
        this.region = region;
        this.Ps = Ps;
        this.Atk = Atk;
        this.Def = Def;
        this.Vel = Vel;
        this.AtkEsp = AtkEsp;
        this.DefEsp = DefEsp;
        this.rareza = rareza;
        this.direccion_imagen = direccion_imagen;
        this.sig = null;
        this.ant = null;
    }
   

    public int getCorrelativo() {
        return correlativo;
    }

    public void setCorrelativo(int correlativo) {
        this.correlativo = correlativo;
    }

    public String getNombre_pk() {
        return nombre_pk;
    }

    public void setNombre_pk(String nombre_pk) {
        this.nombre_pk = nombre_pk;
    }

    public String getTipo_pk() {
        return tipo_pk;
    }

    public void setTipo_pk(String tipo_pk) {
        this.tipo_pk = tipo_pk;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public int getPs() {
        return Ps;
    }

    public void setPs(int Ps) {
        this.Ps = Ps;
    }

    public int getAtk() {
        return Atk;
    }

    public void setAtk(int Atk) {
        this.Atk = Atk;
    }

    public int getDef() {
        return Def;
    }

    public void setDef(int Def) {
        this.Def = Def;
    }

    public int getVel() {
        return Vel;
    }

    public void setVel(int Vel) {
        this.Vel = Vel;
    }

    public int getAtkEsp() {
        return AtkEsp;
    }

    public void setAtkEsp(int AtkEsp) {
        this.AtkEsp = AtkEsp;
    }

    public int getDefEsp() {
        return DefEsp;
    }

    public void setDefEsp(int DefEsp) {
        this.DefEsp = DefEsp;
    }

    public String getRareza() {
        return rareza;
    }

    public void setRareza(String rareza) {
        this.rareza = rareza;
    }

    public String getDireccion_imagen() {
        return direccion_imagen;
    }

    public void setDireccion_imagen(String direccion_imagen) {
        this.direccion_imagen = direccion_imagen;
    }

    public NodoPokemon getSig() {
        return sig;
    }

    public void setSig(NodoPokemon sig) {
        this.sig = sig;
    }

    public NodoPokemon getAnt() {
        return ant;
    }

    public void setAnt(NodoPokemon ant) {
        this.ant = ant;
    }

   
   
   
}
