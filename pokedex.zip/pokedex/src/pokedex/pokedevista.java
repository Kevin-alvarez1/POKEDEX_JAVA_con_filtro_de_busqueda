/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pokedex;
import Pokemon.ListaPokemon;
import Pokemon.Matriz;
import Pokemon.NodoPokemon;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;
import javax.swing.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Player
 */
public class pokedevista extends javax.swing.JFrame {

    public pokedevista() {
    initComponents();
    }
ListaPokemon pokemon = new ListaPokemon();
Matriz regiones = new Matriz();
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnsel = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaarchivo = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        txt_buscar = new javax.swing.JTextField();
        btn_buscar = new javax.swing.JButton();
        MostrarImagen = new javax.swing.JPanel();
        MostImg = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtcorrelativo = new javax.swing.JLabel();
        NombrePk = new javax.swing.JLabel();
        txttipo = new javax.swing.JLabel();
        txtregion = new javax.swing.JLabel();
        txtsalud = new javax.swing.JLabel();
        txtataque = new javax.swing.JLabel();
        txtvelocidad = new javax.swing.JLabel();
        txtdefensa = new javax.swing.JLabel();
        txtatkesp = new javax.swing.JLabel();
        txtdefes = new javax.swing.JLabel();
        txtrareza = new javax.swing.JLabel();
        txtcorre = new javax.swing.JLabel();
        txtname = new javax.swing.JLabel();
        txttipos = new javax.swing.JLabel();
        txtregio = new javax.swing.JLabel();
        txtraro = new javax.swing.JLabel();
        txthp = new javax.swing.JLabel();
        txtatk = new javax.swing.JLabel();
        txtvelos = new javax.swing.JLabel();
        txtdeff = new javax.swing.JLabel();
        txtatkes = new javax.swing.JLabel();
        txtdeffes = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Pokedex");

        jLabel2.setText("Selecciona el archivo");

        btnsel.setText("selecciona");
        btnsel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnselActionPerformed(evt);
            }
        });

        txaarchivo.setColumns(20);
        txaarchivo.setRows(5);
        jScrollPane1.setViewportView(txaarchivo);

        jLabel3.setText("Pokemon");

        txt_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_buscarActionPerformed(evt);
            }
        });

        btn_buscar.setText("buscar");
        btn_buscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_buscarMouseClicked(evt);
            }
        });
        btn_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout MostrarImagenLayout = new javax.swing.GroupLayout(MostrarImagen);
        MostrarImagen.setLayout(MostrarImagenLayout);
        MostrarImagenLayout.setHorizontalGroup(
            MostrarImagenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MostrarImagenLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MostImg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        MostrarImagenLayout.setVerticalGroup(
            MostrarImagenLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MostrarImagenLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MostImg, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );

        txtcorrelativo.setText("Correlativo");

        NombrePk.setText("Nombre");

        txttipo.setText("Tipo");

        txtregion.setText("Region");

        txtsalud.setText("Salud");

        txtataque.setText("Ataque");

        txtvelocidad.setText("Velocidad");

        txtdefensa.setText("Defensa");

        txtatkesp.setText("AtkEs");

        txtdefes.setText("DefEs");

        txtrareza.setText("Rareza");

        txtcorre.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtcorre.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtname.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtname.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txttipos.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txttipos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtregio.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtregio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtraro.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtraro.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txthp.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txthp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtatk.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtatk.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtvelos.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtvelos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtdeff.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtdeff.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtatkes.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtatkes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        txtdeffes.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        txtdeffes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(NombrePk)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtname, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txttipo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txttipos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtregion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtregio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtrareza)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtraro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtcorrelativo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtcorre, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtatkesp)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtatkes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(txtdefensa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtdeff, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(txtvelocidad)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtvelos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(txtataque)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtatk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtsalud)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txthp, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(txtdefes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtdeffes, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtcorrelativo)
                    .addComponent(txtsalud)
                    .addComponent(txtdefes)
                    .addComponent(txtcorre)
                    .addComponent(txthp)
                    .addComponent(txtdeffes))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtataque)
                        .addComponent(txtatk))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(NombrePk)
                        .addComponent(txtname)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtvelocidad)
                        .addComponent(txtvelos))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txttipo)
                        .addComponent(txttipos)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtregion)
                    .addComponent(txtdefensa)
                    .addComponent(txtregio)
                    .addComponent(txtdeff))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtrareza)
                    .addComponent(txtatkesp)
                    .addComponent(txtraro)
                    .addComponent(txtatkes))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(44, 44, 44)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_buscar))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnsel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(MostrarImagen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(txt_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_buscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnsel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(MostrarImagen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnselActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnselActionPerformed
    String path="";
        String[] text;
        long count =0;
        int correlativo = 0;
        int Salud = 0;
        int Ataque = 0;
        int Defensa = 0;
        int Velocidad = 0;
        int AtaEsp = 0;
        int DefEsp = 0;
        try {
            JFileChooser win = new JFileChooser();
            win.showOpenDialog(this);
            File abrir = win.getSelectedFile();

            if (abrir!=null) {
                FileReader archivo = new FileReader(abrir);
                BufferedReader leer = new BufferedReader(archivo);
            while((path=leer.readLine())!=null){
                    System.out.println(path);
                    text = path.split(",");
                    correlativo = Integer.parseInt(text[0]);
                    Salud = Integer.parseInt(text[4]);
                    Ataque = Integer.parseInt(text[5]);
                    Defensa = Integer.parseInt(text[6]);
                    Velocidad = Integer.parseInt(text[7]);
                    AtaEsp = Integer.parseInt(text[8]);
                    DefEsp = Integer.parseInt(text[9]);
                    pokemon.insertar_pokemon(correlativo, text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                    // 1=kanto,2=johto,3=Hoenn,4=Sinnoh,5=Teselia,6=Kalos,7=Alola
                    //1=comun, 2=poco comun,3=legendarios, 4=semi pseudo legendario, 5=singular, 6=fosiles, 7=sub legendario, 8=mega evolucion, 9=ultra ente, 10=pseudo legendario 
             if (   "Kanto".equals(text[3]) ){
                if ("Comun".equals(text[10])){
                    regiones.matriz[0][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Poco-Comun".equals(text[10])){
                    regiones.matriz[1][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Legendario".equals(text[10])){
                    regiones.matriz[2][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Semipseudo-legendario".equals(text[10])){
                    regiones.matriz[3][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Singular".equals(text[10])){
                    regiones.matriz[4][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Fosil".equals(text[10])){
                    regiones.matriz[5][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Sublegendario".equals(text[10])){
                    regiones.matriz[6][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Mega-Evolucion".equals(text[10])){
                    regiones.matriz[7][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Ultraente".equals(text[10])){
                    regiones.matriz[8][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Pseudolegendario".equals(text[10])){
                    regiones.matriz[9][0].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
            } else if("Johto".equals(text[3])){
                 if ("Comun".equals(text[10])){
                    regiones.matriz[0][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Poco-Comun".equals(text[10])){
                    regiones.matriz[1][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Legendario".equals(text[10])){
                    regiones.matriz[2][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Semipseudo-legendario".equals(text[10])){
                    regiones.matriz[3][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Singular".equals(text[10])){
                    regiones.matriz[4][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Fosil".equals(text[10])){
                    regiones.matriz[5][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Sublegendario".equals(text[10])){
                    regiones.matriz[6][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Mega-Evolucion".equals(text[10])){
                    regiones.matriz[7][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Ultraente".equals(text[10])){
                    regiones.matriz[8][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Pseudolegendario".equals(text[10])){
                    regiones.matriz[9][1].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                } 
                
            }else if("Hoenn".equals(text[3])){
                 if ("Comun".equals(text[10])){
                    regiones.matriz[0][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Poco-Comun".equals(text[10])){
                    regiones.matriz[1][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Legendario".equals(text[10])){
                    regiones.matriz[2][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Semipseudo-legendario".equals(text[10])){
                    regiones.matriz[3][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Singular".equals(text[10])){
                    regiones.matriz[4][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Fosil".equals(text[10])){
                    regiones.matriz[5][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Sublegendario".equals(text[10])){
                    regiones.matriz[6][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Mega-Evolucion".equals(text[10])){
                    regiones.matriz[7][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Ultraente".equals(text[10])){
                    regiones.matriz[8][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Pseudolegendario".equals(text[10])){
                    regiones.matriz[9][2].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                } 
                
            }else if("Sinnoh".equals(text[3])){
                 if ("Comun".equals(text[10])){
                    regiones.matriz[0][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Poco-Comun".equals(text[10])){
                    regiones.matriz[1][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Legendario".equals(text[10])){
                    regiones.matriz[2][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Semipseudo-legendario".equals(text[10])){
                    regiones.matriz[3][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Singular".equals(text[10])){
                    regiones.matriz[4][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Fosil".equals(text[10])){
                    regiones.matriz[5][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Sublegendario".equals(text[10])){
                    regiones.matriz[6][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Mega-Evolucion".equals(text[10])){
                    regiones.matriz[7][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Ultraente".equals(text[10])){
                    regiones.matriz[8][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Pseudolegendario".equals(text[10])){
                    regiones.matriz[9][3].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                } 
                
            }else if("Teselia".equals(text[3])){
                 if ("Comun".equals(text[10])){
                    regiones.matriz[0][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Poco-Comun".equals(text[10])){
                    regiones.matriz[1][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Legendario".equals(text[10])){
                    regiones.matriz[2][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Semipseudo-legendario".equals(text[10])){
                    regiones.matriz[3][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Singular".equals(text[10])){
                    regiones.matriz[4][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Fosil".equals(text[10])){
                    regiones.matriz[5][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Sublegendario".equals(text[10])){
                    regiones.matriz[6][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Mega-Evolucion".equals(text[10])){
                    regiones.matriz[7][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Ultraente".equals(text[10])){
                    regiones.matriz[8][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Pseudolegendario".equals(text[10])){
                    regiones.matriz[9][4].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                } 
                
            }else if("Kalos".equals(text[3])){
                 if ("Comun".equals(text[10])){
                    regiones.matriz[0][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Poco-Comun".equals(text[10])){
                    regiones.matriz[1][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Legendario".equals(text[10])){
                    regiones.matriz[2][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Semipseudo-legendario".equals(text[10])){
                    regiones.matriz[3][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Singular".equals(text[10])){
                    regiones.matriz[4][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Fosil".equals(text[10])){
                    regiones.matriz[5][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Sublegendario".equals(text[10])){
                    regiones.matriz[6][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Mega-Evolucion".equals(text[10])){
                    regiones.matriz[7][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Ultraente".equals(text[10])){
                    regiones.matriz[8][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Pseudolegendario".equals(text[10])){
                    regiones.matriz[9][5].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                } 
                
            }else if("Alola".equals(text[3])){
                 if ("Comun".equals(text[10])){
                    regiones.matriz[0][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Poco-Comun".equals(text[10])){
                    regiones.matriz[1][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Legendario".equals(text[10])){
                    regiones.matriz[2][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Semipseudo-legendario".equals(text[10])){
                    regiones.matriz[3][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Singular".equals(text[10])){
                    regiones.matriz[4][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Fosil".equals(text[10])){
                    regiones.matriz[5][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Sublegendario".equals(text[10])){
                    regiones.matriz[6][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Mega-Evolucion".equals(text[10])){
                    regiones.matriz[7][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Ultraente".equals(text[10])){
                    regiones.matriz[8][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                }
                if ("Pseudolegendario".equals(text[10])){
                    regiones.matriz[9][6].insertar_pokemon(correlativo,text[1], text[2], text[3], Salud, Ataque, Defensa, Velocidad, AtaEsp, DefEsp,text[10],text[11]);
                } 
                
            }


            
            
            }
                txaarchivo.setText(pokemon.mostrar());
                leer.close();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnselActionPerformed

    
    private void txt_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_buscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_buscarActionPerformed

    private void btn_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarActionPerformed
        
    }//GEN-LAST:event_btn_buscarActionPerformed

    private void btn_buscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_buscarMouseClicked
        int buscar = Integer.parseInt(txt_buscar.getText());
        pokemon.regresarPK(buscar);
    /*txtcorre.setText("si");
    txtname.setText("si");
    txttipos.setText("si");
    txtregio.setText("si");    
    txtraro.setText("si");
    txthp.setText("si");
    txtatk.setText("si");
    txtvelos.setText("si");
    txtdeff.setText("si");
    txtatkes.setText("si");
    txtdeffes.setText("si");*/
     if (txt_buscar.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor ingresa un dato correcto");
        }else if(isNumeric(txt_buscar.getText())){
           int pk = Integer.parseInt(txt_buscar.getText());
           try{
                //if (pokemon.busqueda(pk)){
                if (regiones.buscarpokemons(pk)){
                    /*String correw = String.valueOf(pokemon.regresarPK(pk).getCorrelativo());
                    txtcorre.setText(correw);
                    String nombress = String.valueOf(pokemon.regresarPK(pk).getNombre_pk());
                    txtname.setText(nombress);
                    txttipos.setText("Tipo: "+pokemon.regresarPK(pk).getTipo_pk());
                    txtregio.setText("Region: "+pokemon.regresarPK(pk).getRegion());
                    txtraro.setText ("Rareza: "+pokemon.regresarPK(pk).getRareza());
                    String saluds = String.valueOf(pokemon.regresarPK(pk).getPs());
                    txthp.setText(saluds);
                    String ataques = String.valueOf(pokemon.regresarPK(pk).getAtk());
                    txtatk.setText(ataques);
                    String defensas = String.valueOf(pokemon.regresarPK(pk).getDef());
                    txtdeff.setText(defensas);
                    String velocidads = String.valueOf(pokemon.regresarPK(pk).getVel());
                    txtvelos.setText(velocidads);
                    String atkes = String.valueOf(pokemon.regresarPK(pk).getAtkEsp());
                    txtatkes.setText(atkes);
                    String defes = String.valueOf(pokemon.regresarPK(pk).getDefEsp());
                    txtdeffes.setText(defes);
                    MostImg.setIcon(new ImageIcon(new URL(pokemon.regresarPK(pk).getDireccion_imagen())));*/
                   String correw = String.valueOf(regiones.buscarpokemon(pk).getCorrelativo());
                    txtcorre.setText(correw);
                    String nombress = String.valueOf(regiones.buscarpokemon(pk).getNombre_pk());
                    txtname.setText(nombress);
                    txttipos.setText("Tipo: "+regiones.buscarpokemon(pk).getTipo_pk());
                    txtregio.setText("Region: "+regiones.buscarpokemon(pk).getRegion());
                    txtraro.setText ("Rareza: "+regiones.buscarpokemon(pk).getRareza());
                    String saluds = String.valueOf(regiones.buscarpokemon(pk).getPs());
                    txthp.setText(saluds);
                    String ataques = String.valueOf(regiones.buscarpokemon(pk).getAtk());
                    txtatk.setText(ataques);
                    String defensas = String.valueOf(regiones.buscarpokemon(pk).getDef());
                    txtdeff.setText(defensas);
                    String velocidads = String.valueOf(regiones.buscarpokemon(pk).getVel());
                    txtvelos.setText(velocidads);
                    String atkes = String.valueOf(regiones.buscarpokemon(pk).getAtkEsp());
                    txtatkes.setText(atkes);
                    String defes = String.valueOf(regiones.buscarpokemon(pk).getDefEsp());
                    txtdeffes.setText(defes);
                    MostImg.setIcon(new ImageIcon(new URL(regiones.buscarpokemon(pk).getDireccion_imagen()))); 
                }else{
                    JOptionPane.showMessageDialog(null, "No se ha encontrado este pokemon");
                }
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Ha ocurrido un error al intentar encontrar este pokemon");
            }
        }
    }//GEN-LAST:event_btn_buscarMouseClicked
    public boolean isNumeric(String cadena){
        try {
        Integer.parseInt(cadena);
        return true;
        } catch (NumberFormatException e) {
        return false;
    }
}


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pokedevista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pokedevista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pokedevista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pokedevista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pokedevista().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel MostImg;
    private javax.swing.JPanel MostrarImagen;
    private javax.swing.JLabel NombrePk;
    private javax.swing.JButton btn_buscar;
    private javax.swing.JButton btnsel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txaarchivo;
    private javax.swing.JTextField txt_buscar;
    private javax.swing.JLabel txtataque;
    private javax.swing.JLabel txtatk;
    private javax.swing.JLabel txtatkes;
    private javax.swing.JLabel txtatkesp;
    private javax.swing.JLabel txtcorre;
    private javax.swing.JLabel txtcorrelativo;
    private javax.swing.JLabel txtdefensa;
    private javax.swing.JLabel txtdefes;
    private javax.swing.JLabel txtdeff;
    private javax.swing.JLabel txtdeffes;
    private javax.swing.JLabel txthp;
    private javax.swing.JLabel txtname;
    private javax.swing.JLabel txtrareza;
    private javax.swing.JLabel txtraro;
    private javax.swing.JLabel txtregio;
    private javax.swing.JLabel txtregion;
    private javax.swing.JLabel txtsalud;
    private javax.swing.JLabel txttipo;
    private javax.swing.JLabel txttipos;
    private javax.swing.JLabel txtvelocidad;
    private javax.swing.JLabel txtvelos;
    // End of variables declaration//GEN-END:variables
   

}

